#include <bits/stdc++.h>

using namespace std;

#define _ ios_base::sync_with_stdio(0);cin.tie(0);
#define FOR(i,a,b) for (int i = a; i < b; ++i)
#define FORS(i,a,b) for (int i = a; i <= b; ++i)
#define FORD(i,a,b) for (int i = a; i > b; --i)
#define FORDS(i,a,b) for (int i = a; i >= b; --i)
#define REP(i,e) FOR (i, 0, e)
#define REPS(i,e) FORS (i, 0, e)
#define REPD(i,e) FORD (i, e, -1)
#define REPDS(i,e) FORDS (i, e, 0)
#define REPA(it,l) for (auto it : l)
#define SET(a,v) memset(a, v, sizeof a)
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define ALL(a) a.begin(), a.end()
#define SZ(a) (int)a.size()
#define nl '\n'

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, ii> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;

const int dx[] = {1, -1, 0, 0, 1, -1, 1, -1};
const int dy[] = {0, 0, 1, -1, -1, -1, 1, 1};
const int INF = 1023123123;
const double eps = 1e-9;

// end of template

const int MASK = 4;

int main() {_
  int a[] = {1, 2, 3, 4, 5}, *b;
  *b = a;
  while (*b) {
    cout << *b++ << nl;
  }
  return 0;
}
